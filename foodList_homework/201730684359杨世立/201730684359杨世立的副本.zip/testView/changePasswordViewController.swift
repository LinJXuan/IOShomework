//
//  changePasswordViewController.swift
//  testView
//
//  Created by Apple on 2019/10/8.
//  Copyright © 2019 hg. All rights reserved.
//

//新建一个cocoa touch类，选择UIViewController
//将按钮拖到这里，并设置一个点击方法
//然后点击按钮销毁当前的view

import UIKit

class changePasswordViewController: UIViewController {

    @IBOutlet weak var changePassword: UIButton!
    @IBAction func changePasswordClick(_ sender: Any) {
        self.dismiss(animated: false
            , completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
