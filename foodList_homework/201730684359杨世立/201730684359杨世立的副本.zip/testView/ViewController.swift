//
//  ViewController.swift
//  testView
//
//  Created by Apple on 2019/9/24.
//  Copyright © 2019 hg. All rights reserved.
//

//写一个exitToHere函数，在Main.storyboard中，将按钮拉到上方的exit，选择exitToHere函数，就可以实现退出



import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var picture: UIImageView!
    
    
    
    @IBOutlet weak var welcomeLabel: UILabel!
    
    
    @IBOutlet weak var userNameText: UITextField!
    
    @IBOutlet weak var passwordText: UITextField!
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    
    @IBOutlet weak var loginButton: UIButton!
    
    
    @IBAction func login(_ sender: Any) {
        
        if let username = userNameText.text{
            welcomeLabel.text = "welcome " + username
        }
        
        if((userNameText.text == "yang")&&(passwordText.text=="123")){
            hintLabel.isHidden = false
            hintLabel.text = "login successfully"
        }else{
            welcomeLabel.isHidden = true
            hintLabel.isHidden = false
            hintLabel.text="login failed,wrong username or password!"
        }
    }
    
    
    @IBAction func exitToHere(segue:UIStoryboardSegue){
        
    }
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

