//
//  descriptionViewController.swift
//  testView
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 hg. All rights reserved.
//

import UIKit

class descriptionViewController: UIViewController {

    @IBOutlet weak var fooddescription: UITextField!
    @IBOutlet weak var foodname: UITextField!
    
    var foodForEdit:food?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.foodname.text=foodForEdit?.name
        self.fooddescription.text=foodForEdit?.foodDescription
        self.navigationItem.title=foodForEdit?.name
        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="saveToList"{
            print("save")
            foodForEdit=food(name:self.foodname.text!,foodDescription: self.fooddescription.text!)
        }
        if segue.identifier=="cancelToList"{
            print("cancel")
        }
        
        
        
        
    }
    

}
