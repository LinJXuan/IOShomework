//
//  ListViewController.swift
//  ioswork
//
//  Created by 最后一排的 on 2019/10/15.
//  Copyright © 2019 Johncompany. All rights reserved.
//

import UIKit

class ListViewController: UIViewController {
    @IBOutlet weak var nameText: UITextField!
    
    @IBOutlet weak var descriptionText: UITextField!
    var foodForEdit: food?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.nameText.text  = foodForEdit?.name
        self.descriptionText.text = foodForEdit?.adescription
        
        // Do any additional setup after loading the view.
    }

    

    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "saveToList"{
            print("save")
            foodForEdit=food(name: self.nameText.text!,adescription: self.descriptionText.text!)
        }
        if segue.identifier == "cancelToList"{
            print("cancel")
        }
    }
 

}
