//
//  food.swift
//  ioswork
//
//  Created by 最后一排的 on 2019/10/15.
//  Copyright © 2019 Johncompany. All rights reserved.
//

import Foundation
class food: NSObject, NSCoding{
    
    var name: String?
    
    var adescription: String?
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name,forKey: "nameKey")
        aCoder.encode(adescription, forKey: "descriptionKey")
        //aCoder.encode(foodCategory,forKey: "categoryKey")
    }
    required init?(coder aDecoder: NSCoder) {
        name=aDecoder.decodeObject(forKey: "nameKey") as? String
        adescription=aDecoder.decodeObject(forKey: "descriptionKey") as? String
    }

    //获取app文件夹的根目录
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    //在根目录下创建子目录
    static let ArchiveURL=DocumentsDirectory.appendingPathComponent("foodList")
    
    init (name:String?, adescription: String?){
        self.name = name;
        self.adescription = adescription;
    }
}
